#!/bin/bash
# This script runs the Discord bot as a workflow
echo "Starting Discord bot..."
python main.py